# PreEmptive Protection JSDefender CLI

## Overview

JSDefender CLI is a wrapper around JSDefender. It allows you to run JSDefender as an executable from the command line. 

To learn about the usage and options head over to the [online docs](https://www.preemptive.com/jsdefender/2.7/userguide/en/index.html).
